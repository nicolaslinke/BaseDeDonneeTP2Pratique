﻿USE master 
GO

-- CREATION ou RECREATION de la BD R22_Billeterie
-- le petit de création ou de recréation de la BD

-- Configuration de FILESTREAM
-- nous avons vu ça lors de la rencontre 19

-- Configuration des clés symétriques
-- il s'agit de créer la clé master, le certificat et enfin la clé symmétrique
USE R22_Billeterie
GO

