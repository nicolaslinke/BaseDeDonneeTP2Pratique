﻿USE R22_Billeterie
GO

CREATE VIEW Spectacles.VW_SpectaclesRepresentationSpectateur
AS
