﻿using WrapUpBilleterie.Models;

namespace WrapUpBilleterie.ViewModels
{
    public class ProfilClientViewModel
    {
        /* Décommentez les lignes ci-dessous lorsque vous aurez complété et appliqué la migration 1.4 et que vous aurez scaffoldé vos données */
        
        //public Client Client { get; set; } = null!;
        //public List<CarteBancaireEnClair> Cartes { get; set; } = null!;
    }
}
