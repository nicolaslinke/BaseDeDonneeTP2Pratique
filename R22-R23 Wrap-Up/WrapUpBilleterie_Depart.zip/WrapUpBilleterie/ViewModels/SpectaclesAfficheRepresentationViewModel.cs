﻿using WrapUpBilleterie.Models;

namespace WrapUpBilleterie.ViewModels
{
    public class SpectaclesAfficheRepresentationViewModel
    {
        /* Décommentez les trois lignes ci-dessous lorsque-vous serez effectuer la migration 1.2 et que vous aurez scaffoldé vos modèles */
        
        //public VwSpectaclesRepresentationSpectateur vwSpectacleVue { get; set; } = null!;
        //public IEnumerable<Representation> Representations { get; set; } = null!;
        //public string? AfficheContent { get; set; }
    }
}
